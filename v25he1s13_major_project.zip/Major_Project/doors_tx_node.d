doors_tx_node.o: Doors_Tx_Node.c
doors_tx_node.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
doors_tx_node.o: types.h
doors_tx_node.o: can.h
doors_tx_node.o: types.h
doors_tx_node.o: delay.h
doors_tx_node.o: defines.h
