interrupts.o: Interrupts.c
interrupts.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
interrupts.o: defines.h
interrupts.o: Interrupts.h
interrupts.o: pin_function_defines.h
interrupts.o: types.h
