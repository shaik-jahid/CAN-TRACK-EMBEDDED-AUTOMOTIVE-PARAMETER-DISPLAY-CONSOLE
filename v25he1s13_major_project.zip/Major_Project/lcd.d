lcd.o: LCD.c
lcd.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
lcd.o: delay.h
lcd.o: lcd.h
lcd.o: defines.h
lcd.o: types.h
lcd.o: LCD_defines.h
