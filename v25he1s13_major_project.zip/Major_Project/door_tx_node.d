door_tx_node.o: Door_Tx_Node.c
door_tx_node.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
door_tx_node.o: can.h
door_tx_node.o: types.h
door_tx_node.o: defines.h
door_tx_node.o: delay.h
door_tx_node.o: can_defines.h
